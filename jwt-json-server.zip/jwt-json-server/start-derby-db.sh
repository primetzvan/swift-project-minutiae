cd db
chmod +x ./db-derby-10.15.2.0-bin/bin/startNetworkServer
./db-derby-10.15.2.0-bin/bin/startNetworkServer -noSecurityManager
