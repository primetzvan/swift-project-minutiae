export class Door {

  id: number;
  name: string;
  ip: string;

  constructor(id: number, name: string, ip: string) {
    this.id = id;
    this.name = name;
    this.ip = ip;
  }
}
